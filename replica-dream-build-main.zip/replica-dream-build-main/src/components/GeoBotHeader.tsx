import { Bot, Home, History, FileText, Settings } from 'lucide-react';
import { Link, useLocation } from 'react-router-dom';

const GeoBotHeader = () => {
  const location = useLocation();
  const currentPath = location.pathname;

  const isActive = (path: string) => currentPath === path;

  return (
    <header className="bg-background border-b border-border px-6 py-3">
      <div className="flex items-center justify-between">
        <Link to="/" className="flex items-center gap-3">
          <div className="w-8 h-8 bg-primary rounded flex items-center justify-center">
            <Bot className="w-5 h-5 text-primary-foreground" />
          </div>
          <div>
            <h1 className="font-semibold text-lg text-foreground">GeoBot</h1>
            <p className="text-sm text-muted-foreground">AI Geospatial Assistant</p>
          </div>
        </Link>
        
        <nav className="flex items-center gap-1">
          <Link 
            to="/app"
            className={`px-4 py-2 text-sm font-medium rounded-md transition-colors ${
              isActive('/app') 
                ? 'text-primary bg-accent' 
                : 'text-muted-foreground hover:text-foreground'
            }`}
          >
            Home
          </Link>
          <Link 
            to="/app/history"
            className={`px-4 py-2 text-sm font-medium rounded-md transition-colors ${
              isActive('/app/history') 
                ? 'text-primary bg-accent' 
                : 'text-muted-foreground hover:text-foreground'
            }`}
          >
            History
          </Link>
          <Link 
            to="/app/reports"
            className={`px-4 py-2 text-sm font-medium rounded-md transition-colors ${
              isActive('/app/reports') 
                ? 'text-primary bg-accent' 
                : 'text-muted-foreground hover:text-foreground'
            }`}
          >
            Reports
          </Link>
          <Link 
            to="/app/settings"
            className={`px-4 py-2 text-sm font-medium rounded-md transition-colors ${
              isActive('/app/settings') 
                ? 'text-primary bg-accent' 
                : 'text-muted-foreground hover:text-foreground'
            }`}
          >
            Settings
          </Link>
        </nav>
      </div>
    </header>
  );
};

export default GeoBotHeader;