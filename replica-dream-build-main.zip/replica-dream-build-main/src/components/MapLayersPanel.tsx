import { useState } from 'react';
import { Checkbox } from '@/components/ui/checkbox';

const MapLayersPanel = () => {
  const [layers, setLayers] = useState({
    floodZones: true,
    roads: true,
    evacuationPoints: true
  });

  const handleLayerToggle = (layerKey: keyof typeof layers) => {
    setLayers(prev => ({
      ...prev,
      [layerKey]: !prev[layerKey]
    }));
  };

  return (
    <div className="w-64 bg-background border-l border-border p-4">
      <h3 className="font-semibold text-sm text-foreground mb-4">Map Layers</h3>
      
      <div className="space-y-3">
        <div className="flex items-center space-x-2">
          <Checkbox
            id="flood-zones"
            checked={layers.floodZones}
            onCheckedChange={() => handleLayerToggle('floodZones')}
          />
          <label
            htmlFor="flood-zones"
            className="text-sm text-foreground font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
          >
            Flood Zones
          </label>
        </div>
        
        <div className="flex items-center space-x-2">
          <Checkbox
            id="roads"
            checked={layers.roads}
            onCheckedChange={() => handleLayerToggle('roads')}
          />
          <label
            htmlFor="roads"
            className="text-sm text-foreground font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
          >
            Roads
          </label>
        </div>
        
        <div className="flex items-center space-x-2">
          <Checkbox
            id="evacuation-points"
            checked={layers.evacuationPoints}
            onCheckedChange={() => handleLayerToggle('evacuationPoints')}
          />
          <label
            htmlFor="evacuation-points"
            className="text-sm text-foreground font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
          >
            Evacuation Points
          </label>
        </div>
      </div>

      {/* Download Report Button */}
      <div className="mt-8 pt-4 border-t border-border">
        <button className="w-full bg-primary text-primary-foreground font-medium py-2 px-4 rounded-md hover:bg-primary/90 transition-colors text-sm">
          Download Report as PDF
        </button>
      </div>
    </div>
  );
};

export default MapLayersPanel;