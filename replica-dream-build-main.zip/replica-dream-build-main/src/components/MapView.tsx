import { ZoomIn, ZoomOut, Layers, Download } from 'lucide-react';
import { Button } from '@/components/ui/button';

const MapView = () => {
  return (
    <div className="flex-1 flex flex-col bg-background">
      {/* Map Header */}
      <div className="p-4 border-b border-border">
        <div className="flex items-center justify-between">
          <h2 className="font-semibold text-lg text-foreground">Interactive Map View</h2>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm">
              <ZoomIn className="w-4 h-4 mr-1" />
              Zoom In
            </Button>
            <Button variant="outline" size="sm">
              <ZoomOut className="w-4 h-4 mr-1" />
              Zoom Out
            </Button>
            <Button variant="outline" size="sm">
              <Layers className="w-4 h-4 mr-1" />
              Layers
            </Button>
            <Button variant="default" size="sm">
              <Download className="w-4 h-4 mr-1" />
              Export
            </Button>
          </div>
        </div>
      </div>

      {/* Map Container */}
      <div className="flex-1 relative">
        <div className="absolute inset-0 bg-map-bg flex items-center justify-center">
          {/* Placeholder map content */}
          <div className="relative w-full h-full">
            {/* Base map representation */}
            <div className="absolute inset-4 bg-gradient-to-br from-blue-100 to-blue-200 rounded-lg border-2 border-blue-300">
              {/* Simulated geographic features */}
              <div className="absolute top-1/3 left-1/4 w-32 h-16 bg-blue-400/30 rounded-lg"></div>
              <div className="absolute top-1/2 right-1/3 w-24 h-12 bg-blue-400/30 rounded-lg"></div>
              
              {/* Road network lines */}
              <svg className="absolute inset-0 w-full h-full">
                <line x1="10%" y1="20%" x2="90%" y2="30%" stroke="#3b82f6" strokeWidth="2" />
                <line x1="20%" y1="40%" x2="80%" y2="60%" stroke="#3b82f6" strokeWidth="2" />
                <line x1="30%" y1="70%" x2="70%" y2="80%" stroke="#3b82f6" strokeWidth="2" />
              </svg>
              
              {/* Flood zones */}
              <div className="absolute top-1/4 left-1/3 w-20 h-24 bg-red-400/40 rounded-lg border border-red-400"></div>
              <div className="absolute bottom-1/3 right-1/4 w-16 h-20 bg-red-400/40 rounded-lg border border-red-400"></div>
              
              {/* Evacuation points */}
              <div className="absolute top-1/3 left-1/2 w-3 h-3 bg-green-500 rounded-full"></div>
              <div className="absolute bottom-1/2 left-1/3 w-3 h-3 bg-green-500 rounded-full"></div>
              <div className="absolute top-2/3 right-1/3 w-3 h-3 bg-green-500 rounded-full"></div>
            </div>
            
            {/* Map attribution */}
            <div className="absolute bottom-6 right-6 bg-background/90 px-2 py-1 rounded text-xs text-muted-foreground">
              OSM/Bhuvan Base Map
            </div>
            
            {/* Interactive Map Display label */}
            <div className="absolute bottom-1/3 right-6 bg-background/90 px-3 py-2 rounded text-sm text-muted-foreground">
              Interactive Map Display
            </div>
          </div>
        </div>

        {/* Legend */}
        <div className="absolute bottom-6 left-6 bg-background border border-border rounded-lg p-3 shadow-sm">
          <h4 className="font-medium text-sm text-foreground mb-2">Legend</h4>
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 bg-red-400 rounded"></div>
              <span className="text-xs text-foreground">Flood Zones</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-1 bg-blue-500"></div>
              <span className="text-xs text-foreground">Roads</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 bg-green-500 rounded-full"></div>
              <span className="text-xs text-foreground">Evacuation Points</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MapView;