import { useState } from 'react';
import { Send, Check, Bot } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';

const QuerySidebar = () => {
  const [query, setQuery] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [hasResults, setHasResults] = useState(true); // Demo data

  const handleSend = () => {
    if (!query.trim()) return;
    
    setIsProcessing(true);
    // Simulate processing
    setTimeout(() => {
      setIsProcessing(false);
      setHasResults(true);
    }, 2000);
  };

  const processingSteps = [
    'Identifying Assam region boundaries',
    'Locating flood-prone zones dataset',
    'Extracting road network data',
    'Performing spatial intersection analysis'
  ];

  const layersAdded = [
    'Flood zones (red polygons)',
    'Road network (blue lines)',
    'Evacuation points (green markers)'
  ];

  return (
    <div className="w-80 bg-sidebar-bg border-r border-border flex flex-col h-full">
      {/* Natural Language Query Section */}
      <div className="p-4 border-b border-border">
        <h2 className="font-semibold text-sm text-foreground mb-2">Natural Language Query</h2>
        <p className="text-xs text-muted-foreground mb-4">Ask GeoBot about geospatial data and analysis</p>
        
        <div className="bg-query-bg rounded-lg p-3 mb-4">
          <p className="text-sm text-primary font-medium">Show flood-prone zones near roads in Assam</p>
        </div>
      </div>

      {/* Processing Status */}
      <div className="p-4 border-b border-border">
        <div className="flex items-center gap-2 mb-3">
          <div className="w-6 h-6 bg-primary rounded-full flex items-center justify-center">
            <Bot className="w-3 h-3 text-primary-foreground" />
          </div>
          <span className="text-sm font-medium text-foreground">GeoBot</span>
        </div>
        
        <p className="text-sm text-foreground mb-3">
          {isProcessing ? 'Processing your request...' : 'Processing your request...'}
        </p>
        
        <div className="space-y-2">
          {processingSteps.map((step, index) => (
            <div key={index} className="flex items-center gap-2">
              <Check className="w-3 h-3 text-success" />
              <span className="text-xs text-muted-foreground">{step}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Analysis Results */}
      {hasResults && (
        <div className="p-4 border-b border-border">
          <h3 className="font-medium text-sm text-foreground mb-2">Analysis Results:</h3>
          <p className="text-xs text-muted-foreground mb-3">
            Found 47 flood-prone zones intersecting with major roads in Assam. The 
            analysis shows high-risk areas primarily along the Brahmaputra river basin 
            affecting NH-37 and NH-15.
          </p>
          
          <h4 className="font-medium text-xs text-foreground mb-2">Map Layers Added:</h4>
          <div className="space-y-1">
            {layersAdded.map((layer, index) => (
              <div key={index} className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-primary" />
                <span className="text-xs text-muted-foreground">{layer}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Confidence */}
      <div className="p-4 border-b border-border">
        <div className="flex items-center justify-between mb-2">
          <span className="text-xs text-muted-foreground">Analysis Confidence:</span>
          <span className="text-xs font-medium text-success">High Confidence</span>
        </div>
        <p className="text-xs text-muted-foreground">Based on 47 data points • Last updated: 2 hours ago</p>
      </div>

      {/* Query Input */}
      <div className="mt-auto p-4">
        <div className="flex gap-2">
          <Textarea
            placeholder="Type your geospatial query here..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="min-h-[60px] resize-none text-sm"
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                handleSend();
              }
            }}
          />
          <Button 
            onClick={handleSend}
            disabled={!query.trim() || isProcessing}
            className="px-3"
          >
            <Send className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </div>
  );
};

export default QuerySidebar;