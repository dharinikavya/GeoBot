import { Clock, Search, Download, Eye } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import GeoBotHeader from '@/components/GeoBotHeader';

const History = () => {
  const queries = [
    {
      id: 1,
      query: "Show me flood risk zones within 5km of downtown Seattle",
      timestamp: "2024-01-15 14:30",
      status: "Completed",
      duration: "2.3s"
    },
    {
      id: 2,
      query: "Find evacuation routes from high-risk areas",
      timestamp: "2024-01-15 14:25",
      status: "Completed",
      duration: "1.8s"
    },
    {
      id: 3,
      query: "Analyze population density near emergency shelters",
      timestamp: "2024-01-15 14:20",
      status: "Completed",
      duration: "3.1s"
    },
    {
      id: 4,
      query: "What are the main transportation corridors in this region?",
      timestamp: "2024-01-15 14:15",
      status: "Completed",
      duration: "1.5s"
    },
    {
      id: 5,
      query: "Identify areas with limited road access",
      timestamp: "2024-01-15 14:10",
      status: "Completed",
      duration: "2.7s"
    }
  ];

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <GeoBotHeader />
      
      <div className="flex-1 p-6">
        <div className="max-w-6xl mx-auto">
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-foreground mb-2">Query History</h1>
            <p className="text-muted-foreground">
              Review your past geospatial queries and access previous results
            </p>
          </div>

          <div className="space-y-4">
            {queries.map((query) => (
              <Card key={query.id} className="border-border hover:shadow-md transition-shadow">
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <CardTitle className="text-lg font-medium text-foreground mb-2">
                        {query.query}
                      </CardTitle>
                      <div className="flex items-center gap-4 text-sm text-muted-foreground">
                        <div className="flex items-center gap-1">
                          <Clock className="w-4 h-4" />
                          {query.timestamp}
                        </div>
                        <div className="flex items-center gap-1">
                          <div className="w-2 h-2 bg-success rounded-full" />
                          {query.status}
                        </div>
                        <div>
                          Duration: {query.duration}
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-2 ml-4">
                      <Button variant="outline" size="sm">
                        <Eye className="w-4 h-4 mr-1" />
                        View
                      </Button>
                      <Button variant="outline" size="sm">
                        <Search className="w-4 h-4 mr-1" />
                        Rerun
                      </Button>
                      <Button variant="outline" size="sm">
                        <Download className="w-4 h-4 mr-1" />
                        Export
                      </Button>
                    </div>
                  </div>
                </CardHeader>
              </Card>
            ))}
          </div>

          {queries.length === 0 && (
            <Card className="border-dashed border-2 border-border">
              <CardContent className="text-center py-12">
                <Clock className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                <CardTitle className="text-xl mb-2">No queries yet</CardTitle>
                <CardDescription>
                  Your query history will appear here once you start using GeoBot
                </CardDescription>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
};

export default History;