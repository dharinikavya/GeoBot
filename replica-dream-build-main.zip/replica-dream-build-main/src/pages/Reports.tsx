import { FileText, Download, Calendar, Eye, Filter } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import GeoBotHeader from '@/components/GeoBotHeader';

const Reports = () => {
  const reports = [
    {
      id: 1,
      title: "Seattle Flood Risk Analysis",
      description: "Comprehensive flood zone analysis with evacuation planning",
      createdAt: "2024-01-15",
      type: "Risk Assessment",
      status: "Ready",
      size: "2.4 MB"
    },
    {
      id: 2,
      title: "Emergency Route Optimization",
      description: "Evacuation route analysis and optimization recommendations",
      createdAt: "2024-01-14",
      type: "Emergency Planning",
      status: "Ready",
      size: "1.8 MB"
    },
    {
      id: 3,
      title: "Population Density Study",
      description: "Demographic analysis near emergency facilities",
      createdAt: "2024-01-13",
      type: "Demographics",
      status: "Ready",
      size: "3.1 MB"
    },
    {
      id: 4,
      title: "Transportation Network Analysis",
      description: "Road network connectivity and accessibility study",
      createdAt: "2024-01-12",
      type: "Infrastructure",
      status: "Processing",
      size: "Pending"
    }
  ];

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'Ready':
        return <Badge className="bg-success text-success-foreground">Ready</Badge>;
      case 'Processing':
        return <Badge variant="secondary">Processing</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  const getTypeColor = (type: string) => {
    const colors: Record<string, string> = {
      'Risk Assessment': 'bg-destructive/10 text-destructive',
      'Emergency Planning': 'bg-primary/10 text-primary',
      'Demographics': 'bg-accent text-accent-foreground',
      'Infrastructure': 'bg-secondary text-secondary-foreground'
    };
    return colors[type] || 'bg-muted text-muted-foreground';
  };

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <GeoBotHeader />
      
      <div className="flex-1 p-6">
        <div className="max-w-6xl mx-auto">
          <div className="flex items-center justify-between mb-8">
            <div>
              <h1 className="text-3xl font-bold text-foreground mb-2">Reports</h1>
              <p className="text-muted-foreground">
                Access and download your generated geospatial analysis reports
              </p>
            </div>
            <div className="flex items-center gap-3">
              <Button variant="outline">
                <Filter className="w-4 h-4 mr-2" />
                Filter
              </Button>
              <Button>
                Generate New Report
              </Button>
            </div>
          </div>

          <div className="grid gap-6">
            {reports.map((report) => (
              <Card key={report.id} className="border-border hover:shadow-md transition-shadow">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <CardTitle className="text-xl font-semibold text-foreground">
                          {report.title}
                        </CardTitle>
                        {getStatusBadge(report.status)}
                      </div>
                      <CardDescription className="text-base mb-3">
                        {report.description}
                      </CardDescription>
                      <div className="flex items-center gap-6 text-sm text-muted-foreground">
                        <div className="flex items-center gap-1">
                          <Calendar className="w-4 h-4" />
                          Created {report.createdAt}
                        </div>
                        <Badge 
                          variant="outline" 
                          className={`${getTypeColor(report.type)} border-current`}
                        >
                          {report.type}
                        </Badge>
                        <div>
                          Size: {report.size}
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-2 ml-6">
                      <Button variant="outline" size="sm">
                        <Eye className="w-4 h-4 mr-1" />
                        Preview
                      </Button>
                      <Button 
                        variant="outline" 
                        size="sm"
                        disabled={report.status !== 'Ready'}
                      >
                        <Download className="w-4 h-4 mr-1" />
                        Download
                      </Button>
                    </div>
                  </div>
                </CardHeader>
              </Card>
            ))}
          </div>

          {reports.length === 0 && (
            <Card className="border-dashed border-2 border-border">
              <CardContent className="text-center py-12">
                <FileText className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                <CardTitle className="text-xl mb-2">No reports generated</CardTitle>
                <CardDescription>
                  Your generated reports will appear here. Start by running some queries to create your first report.
                </CardDescription>
                <Button className="mt-4">
                  Generate First Report
                </Button>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
};

export default Reports;