import { Bot, Map, MessageSquare, FileText, Zap, Shield } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Link } from 'react-router-dom';

const Landing = () => {
  const features = [
    {
      icon: MessageSquare,
      title: "Natural Language Queries",
      description: "Ask questions in plain English and get instant geospatial insights. No complex GIS knowledge required."
    },
    {
      icon: Map,
      title: "Interactive Maps",
      description: "Visualize data on dynamic maps with multiple layers including flood zones, roads, and evacuation points."
    },
    {
      icon: Zap,
      title: "Real-time Processing",
      description: "Get instant results with our AI-powered geospatial analysis engine that processes queries in seconds."
    },
    {
      icon: FileText,
      title: "Automated Reports",
      description: "Generate comprehensive PDF reports with maps, analysis, and actionable insights automatically."
    },
    {
      icon: Shield,
      title: "Emergency Planning",
      description: "Specialized tools for disaster response, evacuation planning, and risk assessment."
    },
    {
      icon: Bot,
      title: "AI Assistant",
      description: "Your intelligent geospatial companion that learns from your queries and provides better insights over time."
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-background border-b border-border px-6 py-4">
        <div className="flex items-center justify-between max-w-7xl mx-auto">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-primary rounded flex items-center justify-center">
              <Bot className="w-6 h-6 text-primary-foreground" />
            </div>
            <div>
              <h1 className="font-bold text-xl text-foreground">GeoBot</h1>
              <p className="text-sm text-muted-foreground">AI Geospatial Assistant</p>
            </div>
          </div>
          
          <nav className="flex items-center gap-6">
            <Link to="/app" className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors">
              App
            </Link>
            <Link to="/app/history" className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors">
              History
            </Link>
            <Link to="/app/reports" className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors">
              Reports
            </Link>
            <Button asChild>
              <Link to="/app">Get Started</Link>
            </Button>
          </nav>
        </div>
      </header>

      {/* Hero Section */}
      <section className="px-6 py-20 bg-gradient-to-br from-background to-accent/20">
        <div className="max-w-7xl mx-auto text-center">
          <div className="max-w-3xl mx-auto">
            <h1 className="text-5xl font-bold text-foreground mb-6">
              Transform Your Geospatial Analysis with{' '}
              <span className="text-primary">AI</span>
            </h1>
            <p className="text-xl text-muted-foreground mb-8 leading-relaxed">
              Ask questions in natural language and get instant geospatial insights. 
              GeoBot makes complex spatial analysis accessible to everyone, from emergency planners to researchers.
            </p>
            <div className="flex gap-4 justify-center">
              <Button size="lg" asChild>
                <Link to="/app">Start Analyzing</Link>
              </Button>
              <Button variant="outline" size="lg">
                Watch Demo
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Features Grid */}
      <section className="px-6 py-20">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-foreground mb-4">
              Powerful Features for Every Use Case
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              From disaster response to urban planning, GeoBot provides the tools you need for intelligent geospatial analysis.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <Card key={index} className="border-border hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                    <feature.icon className="w-6 h-6 text-primary" />
                  </div>
                  <CardTitle className="text-xl">{feature.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-base leading-relaxed">
                    {feature.description}
                  </CardDescription>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="px-6 py-20 bg-primary text-primary-foreground">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl font-bold mb-4">
            Ready to revolutionize your geospatial workflow?
          </h2>
          <p className="text-xl opacity-90 mb-8">
            Join thousands of professionals who trust GeoBot for their spatial analysis needs.
          </p>
          <Button size="lg" variant="secondary" asChild>
            <Link to="/app">Get Started Free</Link>
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border px-6 py-8">
        <div className="max-w-7xl mx-auto text-center">
          <div className="flex items-center justify-center gap-3 mb-4">
            <div className="w-8 h-8 bg-primary rounded flex items-center justify-center">
              <Bot className="w-5 h-5 text-primary-foreground" />
            </div>
            <span className="font-semibold text-foreground">GeoBot</span>
          </div>
          <p className="text-sm text-muted-foreground">
            © 2024 GeoBot. AI-powered geospatial analysis for everyone.
          </p>
        </div>
      </footer>
    </div>
  );
};

export default Landing;