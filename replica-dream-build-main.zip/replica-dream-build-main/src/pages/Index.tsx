import GeoBotHeader from '@/components/GeoBotHeader';
import QuerySidebar from '@/components/QuerySidebar';
import MapView from '@/components/MapView';
import MapLayersPanel from '@/components/MapLayersPanel';

const Index = () => {
  return (
    <div className="min-h-screen bg-background flex flex-col">
      <GeoBotHeader />
      <div className="flex flex-1">
        <QuerySidebar />
        <MapView />
        <MapLayersPanel />
      </div>
    </div>
  );
};

export default Index;
